﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using MyBank.Models;

namespace MyBank.Controllers
{
    public class NoBankController : Controller
    {
        // EF context (fully qualified to match project namespace)
        private readonly MyBank.Models.NobankdbEntities _db = new MyBank.Models.NobankdbEntities();

        public ActionResult Index()
        {
            var list = _db.Departments.ToList();
            return View(list);
        }
       


    // GET: Login
    public ActionResult Login()
            {
                // Show any success messages (e.g., after registration)
                ViewBag.Message = TempData["Message"] as string;
                return View();
            }

            // POST: Login
            [HttpPost]
            public ActionResult Login(string username, string password)
            {
                // Basic input validation
                if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
                {
                    ModelState.AddModelError("", "Username and password are required.");
                    return View();
                }

                try
                {
                    var hashed = HashPassword(password);

                    // Use EF LINQ to query safely
                    var user = _db.UserLogins
                                  .FirstOrDefault(u => u.UserName == username && u.PasswordHash == hashed);

                    if (user != null)
                    {
                        // Store limited user info in session (avoid storing password)
                        Session["User"] = new
                        {
                            user.UserID,
                            user.UserName,
                            user.Role,
                            user.ReferenceID
                        };

                        // Store reference id separately for easy access in account flows
                        Session["ReferenceID"] = user.ReferenceID;

                        // Redirect based on role if needed
                        if (!string.IsNullOrEmpty(user.Role) && user.Role.Equals("Employee", StringComparison.OrdinalIgnoreCase))
                        {
                            return RedirectToAction("EmployeePage");
                        }

                        return RedirectToAction("CustomerPage");
                    }

                    ModelState.AddModelError("", "Invalid username or password.");
                    return View();
                }
                catch (Exception)
                {
                    // Log exception as needed. Show generic error.
                    ModelState.AddModelError("", "An error occurred while attempting to log in.");
                    return View();
                }
            }

            // GET: Signup
            public ActionResult Signup()
            {
                return View();
            }

            // POST: Signup
            [HttpPost]
            public ActionResult Signup(string username, string password, string confirmPassword, string pan)
            {
                // Basic validation
                if (string.IsNullOrWhiteSpace(username) ||
                    string.IsNullOrWhiteSpace(password) ||
                    string.IsNullOrWhiteSpace(confirmPassword) ||
                    string.IsNullOrWhiteSpace(pan))
                {
                    ModelState.AddModelError("", "All fields are required.");
                    return View();
                }

                if (password != confirmPassword)
                {
                    ModelState.AddModelError("", "The passwords do not match.");
                    return View();
                }

                // Validate PAN alphanumeric
                if (!Regex.IsMatch(pan, "^[a-zA-Z0-9]+$"))
                {
                    ModelState.AddModelError("", "PAN must be alphanumeric.");
                    return View();
                }

                try
                {
                    // Check if username is already taken
                    var existing = _db.UserLogins.FirstOrDefault(u => u.UserName == username);
                    if (existing != null)
                    {
                        ModelState.AddModelError("", "Username is already taken.");
                        return View();
                    }

                    // Generate a simple 8-char customer id (CHAR(8) in DB)
                    string custId;
                    do
                    {
                        custId = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpperInvariant();
                    } while (_db.Customers.Any(c => c.Custid == custId));

                    // UserID in DB is VARCHAR(20) - ensure generated id fits
                    var userId = "USR" + Guid.NewGuid().ToString("N").Substring(0, 17).ToUpperInvariant();

                    var user = new UserLogin
                    {
                        UserID = userId,
                        UserName = username,
                        PasswordHash = HashPassword(password),
                        Role = "CUSTOMER",
                        ReferenceID = custId
                    };

                    var cust = new Customer
                    {
                        Custid = custId,
                        Custname = username,
                        DOB = null,
                        Pan = pan,
                        Address = null,
                        PhoneNumber = null
                    };

                    _db.UserLogins.Add(user);
                    _db.Customers.Add(cust);
                    _db.SaveChanges();

                    // Set session so subsequent actions (e.g., SavingAcc) can pick up customer id
                    Session["User"] = new
                    {
                        user.UserID,
                        user.UserName,
                        user.Role,
                        user.ReferenceID
                    };
                    Session["ReferenceID"] = custId;

                    // Redirect to CustomerPage so user can complete profile / open accounts
                    return RedirectToAction("CustomerPage");
                }
                catch (Exception)
                {
                    // Log exception as needed
                    ModelState.AddModelError("", "An error occurred while creating the account.");
                    return View();
                }
            }

        public ActionResult Register()
        {
            return View();
        }
        public ActionResult ManagerPage()
        {
            // Show any success messages (e.g., after creating a manager)
            ViewBag.Message = TempData["MgrMessage"] as string;

            // Provide current managers for display on the page (optional)
            try
            {
                ViewBag.Managers = _db.Managers.ToList();
            }
            catch
            {
                ViewBag.Managers = Enumerable.Empty<Manager>().ToList();
            }

            return View();
        }

        // POST: ManagerPage - create new Manager record
        [HttpPost]
        public ActionResult ManagerPage([Bind(Include = "ManagerID,ManagerName,PAN")] Manager model)
        {
            // Repopulate managers list for redisplay on error
            try
            {
                ViewBag.Managers = _db.Managers.ToList();
            }
            catch
            {
                ViewBag.Managers = Enumerable.Empty<Manager>().ToList();
            }

            if (model == null)
            {
                ModelState.AddModelError("", "Invalid submission.");
                return View(model);
            }

            // Required field validation
            if (string.IsNullOrWhiteSpace(model.ManagerID) ||
                string.IsNullOrWhiteSpace(model.ManagerName) ||
                string.IsNullOrWhiteSpace(model.PAN))
            {
                ModelState.AddModelError("", "ManagerID, ManagerName and PAN are required.");
                return View(model);
            }

            try
            {
                // Check duplicate ManagerID
                var exists = _db.Managers.FirstOrDefault(m => m.ManagerID == model.ManagerID);
                if (exists != null)
                {
                    ModelState.AddModelError("", "A manager with that ID already exists.");
                    return View(model);
                }

                // Create and save
                var mgr = new Manager
                {
                    ManagerID = model.ManagerID,
                    ManagerName = model.ManagerName,
                    PAN = model.PAN
                };

                _db.Managers.Add(mgr);
                _db.SaveChanges();

                TempData["MgrMessage"] = "Manager created successfully.";
                return RedirectToAction("ManagerPage");
            }
            catch (Exception)
            {
                // Log exception as needed
                ModelState.AddModelError("", "An error occurred while creating the manager.");
                return View(model);
            }
        }
        public ActionResult EmployeePage()
        {
            // Populate departments for a dropdown in the view
            ViewBag.Message = TempData["EmpMessage"] as string;
            ViewBag.Departments = new SelectList(_db.Departments.ToList(), "Deptid", "Deptname");
            return View();
        }

        // POST: EmployeePage - create new Employee record
        [HttpPost]
        public ActionResult EmployeePage([Bind(Include = "Empid,EmployeeName,DeptId,Pan")] Employee model)
        {
            // Repopulate departments for redisplay on error
            ViewBag.Departments = new SelectList(_db.Departments.ToList(), "Deptid", "Deptname");

            if (model == null)
            {
                ModelState.AddModelError("", "Invalid submission.");
                return View(model);
            }

            // Basic validation
            if (string.IsNullOrWhiteSpace(model.Empid) ||
                string.IsNullOrWhiteSpace(model.EmployeeName) ||
                string.IsNullOrWhiteSpace(model.DeptId))
            {
                ModelState.AddModelError("", "EmpID, Employee Name and DeptId are required.");
                return View(model);
            }

            try
            {
                // Check duplicate Empid
                var exists = _db.Employees.FirstOrDefault(e => e.Empid == model.Empid);
                if (exists != null)
                {
                    ModelState.AddModelError("", "An employee with that ID already exists.");
                    return View(model);
                }

                // Create and save
                var emp = new Employee
                {
                    Empid = model.Empid,
                    EmployeeName = model.EmployeeName,
                    DeptId = model.DeptId,
                    Pan = model.Pan
                };

                _db.Employees.Add(emp);
                _db.SaveChanges();

                TempData["EmpMessage"] = "Employee created successfully.";
                return RedirectToAction("EmployeePage");
            }
            catch (Exception)
            {
                // Log exception as needed
                ModelState.AddModelError("", "An error occurred while creating the employee.");
                return View(model);
            }
        }
        public ActionResult CustomerPage()
        {
            ViewBag.Message = TempData["CustMessage"] as string;

            // Try to read the reference id from session
            var refId = Session["ReferenceID"] as string;
            Customer model = null;

            if (!string.IsNullOrEmpty(refId))
            {
                model = _db.Customers.FirstOrDefault(c => c.Custid == refId);
            }

            // If not found, return an empty model with Custid prefilled if possible
            if (model == null)
            {
                model = new Customer
                {
                    Custid = refId ?? string.Empty
                };
            }

            return View(model);
        }
        [HttpPost]
        public ActionResult CustomerPage([Bind(Include = "Custid,Custname,DOB,Pan,Address,PhoneNumber")] Customer model)
        {
            if (model == null)
            {
                ModelState.AddModelError("", "Invalid submission.");
                return View(model);
            }

            // Get reference id from session if available (preferred)
            var refId = Session["ReferenceID"] as string;
            var custIdToUse = !string.IsNullOrWhiteSpace(refId) ? refId : model.Custid;

            if (string.IsNullOrWhiteSpace(custIdToUse) || string.IsNullOrWhiteSpace(model.Custname))
            {
                ModelState.AddModelError("", "Customer ID and Name are required.");
                return View(model);
            }

            try
            {
                var existing = _db.Customers.FirstOrDefault(c => c.Custid == custIdToUse);
                if (existing != null)
                {
                    // Update existing
                    existing.Custname = model.Custname;
                    existing.DOB = model.DOB;
                    existing.Pan = model.Pan;
                    existing.Address = model.Address;
                    existing.PhoneNumber = model.PhoneNumber;

                    _db.Entry(existing).State = System.Data.Entity.EntityState.Modified;
                }
                else
                {
                    // Create new tied to reference id
                    var cust = new Customer
                    {
                        Custid = custIdToUse,
                        Custname = model.Custname,
                        DOB = model.DOB,
                        Pan = model.Pan,
                        Address = model.Address,
                        PhoneNumber = model.PhoneNumber
                    };
                    _db.Customers.Add(cust);
                }

                _db.SaveChanges();

                TempData["CustMessage"] = "Customer profile saved successfully.";
                return RedirectToAction("CustomerPage");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "An error occurred while saving the customer.");
                return View(model);
            }
        }
        public ActionResult SavingAcc()
        {
            // Ensure user/customer reference is available
            var refId = Session["ReferenceID"] as string;
            if (string.IsNullOrWhiteSpace(refId))
            {
                // Not signed in / no linked customer — send to login
                return RedirectToAction("Login");
            }

            // Load customer including navigation collections if needed
            var customer = _db.Customers
                              .FirstOrDefault(c => c.Custid == refId);

            if (customer == null)
            {
                // If no customer exists, redirect to CustomerPage to create profile
                TempData["CustMessage"] = "Please complete your customer profile first.";
                return RedirectToAction("CustomerPage");
            }

            return View(customer);
        }
        [HttpPost]
        public ActionResult SavingAcc(decimal? initialDeposit)
        {
            var refId = Session["ReferenceID"] as string;
            if (string.IsNullOrWhiteSpace(refId))
            {
                return RedirectToAction("Login");
            }

            if (initialDeposit == null || initialDeposit < 0m)
            {
                ModelState.AddModelError("", "Initial deposit must be a non-negative amount.");
                // Reload customer for redisplay
                var customer = _db.Customers.FirstOrDefault(c => c.Custid == refId);
                return View(customer);
            }

            try
            {
                // Generate account id and create SavingsAccount
                // enforce DB constraints: SBAccountID CHAR(7) and Balance > 1000
                if (!initialDeposit.HasValue || initialDeposit.Value <= 1000m)
                {
                    ModelState.AddModelError("", "Initial deposit must be greater than 1000.");
                    var customerErr = _db.Customers.FirstOrDefault(c => c.Custid == refId);
                    return View(customerErr);
                }

                string sbId;
                do
                {
                    sbId = Guid.NewGuid().ToString("N").Substring(0, 7).ToUpperInvariant();
                } while (_db.Accounts.Any(a => a.AccountID == sbId) || _db.SavingsAccounts.Any(s => s.SBAccountID == sbId));

                var sa = new SavingsAccount
                {
                    SBAccountID = sbId,
                    Customerid = refId,
                    Balance = initialDeposit
                };

                // Create Account wrapper record consistent with DB constraints
                var account = new Account
                {
                    AccountID = sbId,
                    AccountType = "SAVING",
                    CustomerID = refId,
                    // OpenedBy/OpenRole should be null for customer self-opened accounts
                    OpenedBy = null,
                    OpenedByRole = null,
                    OpenDate = DateTime.Now.Date,
                    Status = "OPEN"
                };

                _db.SavingsAccounts.Add(sa);
                _db.Accounts.Add(account);
                _db.SaveChanges();

                TempData["CustMessage"] = "Savings account created successfully.";
                return RedirectToAction("CustomerPage");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "An error occurred while creating the savings account.");
                var customer = _db.Customers.FirstOrDefault(c => c.Custid == refId);
                return View(customer);
            }
        }
        public ActionResult LoanAcc()
        {
            return View();
        }
        public ActionResult Reports()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
            base.Dispose(disposing);
        }

        // Helper: SHA256 hash -> base64
        private string HashPassword(string password)
        {
            if (password == null) return null;
            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}