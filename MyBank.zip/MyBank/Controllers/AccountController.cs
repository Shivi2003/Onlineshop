﻿using System.Linq;
using System.Web.Mvc;
using MyBank.Models;

namespace MyBank.Controllers
{
    public class AccountController : Controller
    {
        private NobankdbEntities db = new NobankdbEntities();

        // GET: Signup
        public ActionResult Signup()
        {
            return View();
        }

        // POST: Signup
        [HttpPost]
        public ActionResult Signup(UserLogin user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = db.UserLogins.FirstOrDefault(u => u.UserName == user.UserName);
                if (existingUser != null)
                {
                    ViewBag.Message = "User already registered!";
                    return View(user);
                }

                // Ensure UserID is set if the DB or view expects it (optional)
                if (string.IsNullOrWhiteSpace(user.UserID))
                {
                    // simple ID assignment; adjust to your preferred ID generation
                    user.UserID = System.Guid.NewGuid().ToString();
                }

                db.UserLogins.Add(user);
                db.SaveChanges();

                ViewBag.Message = "Signup successful! Please login now.";
                return RedirectToAction("Login");
            }

            return View(user);
        }

        // GET: Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public ActionResult Login(string userName, string password, string role)
        {
            var user = db.UserLogins.FirstOrDefault(u =>
                u.UserName == userName &&
                u.PasswordHash == password &&
                u.Role == role);

            if (user != null)
            {
                Session["UserId"] = user.UserID;
                Session["UserName"] = user.UserName;
                Session["UserRole"] = user.Role;

                // Redirect to NoBank controller area based on role
                if (string.Equals(user.Role, "Customer", System.StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction("CustomerPage", "NoBank");
                }
                if (string.Equals(user.Role, "Employee", System.StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction("EmployeePage", "NoBank");
                }
                if (string.Equals(user.Role, "Manager", System.StringComparison.OrdinalIgnoreCase))
                {
                    return RedirectToAction("ManagerPage", "NoBank");
                }

                return RedirectToAction("Index", "NoBank");
            }

            ViewBag.Message = "Invalid login details!";
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}